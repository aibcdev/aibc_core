
import React, { useState } from 'react';
import { 
  Twitter, Linkedin, Instagram, Facebook, AtSign, Pin, 
  Youtube, Music2, Twitch, Globe, ArrowRight 
} from 'lucide-react';
import { ViewState, NavProps } from '../types';

const VectorsView: React.FC<NavProps> = ({ onNavigate }) => {
  const [keywords, setKeywords] = useState('');

  return (
    <div id="vectors-view" className="fixed inset-0 z-[90] bg-[#000] overflow-y-auto animate-in fade-in duration-500">
        <div className="min-h-screen flex flex-col p-6 md:p-12 relative max-w-6xl mx-auto">
            
            {/* Header */}
            <div className="flex items-center justify-between mb-12 border-b border-white/10 pb-6">
                <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-white">Target Vectors</h1>
                <button 
                  onClick={() => onNavigate(ViewState.DASHBOARD)}
                  className="px-4 py-1.5 rounded-full border border-white/10 text-[10px] font-medium text-white/30 uppercase tracking-widest hover:border-white/20 hover:text-white transition-colors"
                >
                    Finalize
                </button>
            </div>

            {/* Main Content Grid */}
            <div className="space-y-6 mb-12">
                
                {/* Social Media Section */}
                <div className="rounded-xl border border-white/10 bg-[#080808] p-6 md:p-8">
                    <div className="flex items-center gap-4 mb-8">
                        <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500 border border-blue-500/20">
                            <Twitter className="w-5 h-5 fill-current" />
                        </div>
                        <h2 className="text-lg font-black uppercase tracking-wide text-white">Social Media</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <VectorCard icon={Linkedin} label="LINKEDIN" />
                        <VectorCard icon={Twitter} label="X / TWITTER" defaultChecked />
                        <VectorCard icon={Instagram} label="INSTAGRAM" />
                        <VectorCard icon={Facebook} label="FACEBOOK" />
                        <VectorCard icon={AtSign} label="THREADS" />
                        <VectorCard icon={Pin} label="PINTEREST" />
                    </div>
                </div>

                {/* Video & Audio Section */}
                <div className="rounded-xl border border-white/10 bg-[#080808] p-6 md:p-8">
                    <div className="flex items-center gap-4 mb-8">
                        <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center text-red-500 border border-red-500/20">
                            <Youtube className="w-5 h-5" />
                        </div>
                        <h2 className="text-lg font-black uppercase tracking-wide text-white">Video & Audio</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <VectorCard icon={Youtube} label="YOUTUBE" />
                        <VectorCard icon={Music2} label="TIKTOK" />
                        <VectorCard icon={Twitch} label="TWITCH" />
                    </div>
                </div>

                {/* Blog & Web Section */}
                <div className="rounded-xl border border-white/10 bg-[#080808] p-6 md:p-8">
                    <div className="flex items-center gap-4 mb-8">
                        <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center text-green-500 border border-green-500/20">
                            <Globe className="w-5 h-5" />
                        </div>
                        <h2 className="text-lg font-black uppercase tracking-wide text-white">Blog & Web</h2>
                    </div>

                    <div className="space-y-4">
                        <VectorCard icon={Globe} label="WORDPRESS / CMS INTEGRATION" />

                        <div className="relative group">
                            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                                <span className="w-4 h-0.5 bg-white/20 group-focus-within:bg-green-500/50 transition-colors"></span>
                            </div>
                            <input 
                              type="text" 
                              value={keywords}
                              onChange={(e) => setKeywords(e.target.value)}
                              placeholder="ENTER TARGET KEYWORDS (COMMA SEPARATED)" 
                              className="w-full bg-[#050505] border border-white/10 rounded-lg py-4 pl-12 pr-4 text-xs font-mono text-white placeholder:text-white/20 focus:outline-none focus:border-green-500/50 focus:ring-1 focus:ring-green-500/50 uppercase tracking-wide transition-all" 
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Footer Action Bar */}
            <div className="flex items-center justify-between border-t border-white/10 pt-8 mt-auto sticky bottom-0 bg-[#000] pb-6 z-10">
                <button 
                  onClick={() => onNavigate(ViewState.AUDIT)}
                  className="px-6 py-3 rounded border border-white/20 text-xs font-bold uppercase tracking-widest text-white hover:bg-white/5 transition-colors"
                >
                    Back
                </button>
                <button 
                  onClick={() => onNavigate(ViewState.DASHBOARD)}
                  className="px-8 py-3 rounded bg-[#10B981] hover:bg-[#059669] text-[#050505] text-xs font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all flex items-center gap-2"
                >
                    Initialize Dashboard <ArrowRight className="w-3 h-3" />
                </button>
            </div>
        </div>
    </div>
  );
};

const VectorCard = ({ icon: Icon, label, defaultChecked }: { icon: any, label: string, defaultChecked?: boolean }) => {
  const [checked, setChecked] = useState(defaultChecked || false);

  return (
    <label className="cursor-pointer group relative">
        <input 
          type="checkbox" 
          className="hidden" 
          checked={checked} 
          onChange={(e) => setChecked(e.target.checked)}
        />
        <div className={`rounded-lg border p-4 flex items-center gap-4 transition-all h-full ${
          checked 
            ? 'border-green-500 bg-green-500/5' 
            : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.05]'
        }`}>
            <Icon className={`w-5 h-5 transition-colors ${checked ? 'text-green-500' : 'text-white/40'}`} />
            <span className={`text-xs font-bold tracking-wider transition-colors ${checked ? 'text-white' : 'text-white/70'}`}>
              {label}
            </span>
            {checked && (
               <div className="absolute right-4 top-1/2 -translate-y-1/2 h-2 w-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
            )}
        </div>
    </label>
  );
};

export default VectorsView;
