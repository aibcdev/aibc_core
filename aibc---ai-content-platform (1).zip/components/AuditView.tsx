import React, { useEffect, useState } from 'react';
import { Network, ArrowRight } from 'lucide-react';
import { ViewState, NavProps } from '../types';
import { generateAuditLogs } from '../services/geminiService';

interface AuditProps extends NavProps {
  username: string;
}

const AuditView: React.FC<AuditProps> = ({ onNavigate, username }) => {
  const [logs, setLogs] = useState<string[]>([]);
  const [showButton, setShowButton] = useState(false);

  useEffect(() => {
    let mounted = true;
    
    const fetchLogs = async () => {
      // Initial fake logs for immediate feedback
      setLogs([
        "[SYSTEM] Initializing n8n Workflow Engine...",
        "[AGENT: STRATEGIST] Synthesis Complete. Generating Brand Constitution.",
        "[METRICS] Footprint Score: 42/100",
        "[INSIGHT] 2 Competitors Identified in War Room."
      ]);

      // Fetch AI generated logs
      const aiLogs = await generateAuditLogs(username);
      
      if (mounted) {
        // Append AI logs one by one for effect
        aiLogs.forEach((log, index) => {
          setTimeout(() => {
            setLogs(prev => [...prev, `[ANALYSIS] ${log}`]);
          }, (index + 1) * 800);
        });

        // Show button after a delay
        setTimeout(() => {
          setShowButton(true);
        }, 4000);
      }
    };

    fetchLogs();

    return () => { mounted = false; };
  }, [username]);

  return (
    <div className="fixed inset-0 z-[80] bg-[#050505] overflow-y-auto animate-in fade-in duration-500">
      <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
        
        {/* Circular Loader */}
        <div className="relative w-48 h-48 mb-12 flex items-center justify-center">
             {/* Rotating Gradient Border */}
             <div className="absolute inset-0 rounded-full border border-white/10"></div>
             <div className="absolute inset-0 rounded-full border-t border-green-500/50 border-r border-purple-500/50 blur-[1px] animate-spin-slow"></div>
             <div className="absolute inset-0 rounded-full border-t border-green-500 border-r border-transparent animate-spin duration-[3s] linear"></div>
             
             {/* Inner Content */}
             <div className="flex flex-col items-center gap-4 z-10">
                 <Network className="w-10 h-10 text-white mb-2" />
                 <span className="text-[10px] font-mono font-bold text-green-500 tracking-widest uppercase animate-pulse">Agents Active</span>
             </div>
        </div>

        {/* Text */}
        <h2 className="text-4xl md:text-5xl font-sans font-black tracking-tighter text-white mb-4 uppercase text-center leading-none">
            Forensic Digital Audit...
        </h2>
        <p className="font-mono text-xs md:text-sm text-[#666] mb-12 text-center tracking-tight">
            Orchestrating n8n workflow nodes & Perplexity checks
        </p>

        {/* Terminal Box */}
        <div className="w-full max-w-3xl bg-[#080808] rounded-xl border border-white/10 p-6 md:p-10 font-mono text-xs md:text-sm shadow-2xl relative overflow-hidden mb-12">
             <div className="absolute inset-0 pointer-events-none z-20 scanlines opacity-50"></div>
             
             <div className="space-y-4 relative z-10">
                {logs.map((log, i) => (
                  <div key={i} className="flex gap-4 border-b border-white/[0.03] pb-2 animate-in slide-in-from-left-2 duration-300">
                      <span className="text-pink-500 font-bold">&gt;</span>
                      <span className="text-white/40">[{new Date().toLocaleTimeString()}]</span>
                      <span className="text-white">{log}</span>
                  </div>
                ))}
                
                <div className="flex gap-4 pt-2">
                    <span className="text-green-500 font-bold">&gt;</span>
                    <span className="animate-pulse text-green-500 font-bold">_</span>
                </div>
             </div>
        </div>

        {/* Proceed Button */}
        {showButton && (
            <button 
              onClick={() => onNavigate(ViewState.VECTORS)} 
              className="animate-in fade-in slide-in-from-bottom-4 duration-700 px-8 py-3 rounded-full border border-white/20 bg-white/5 hover:bg-white/10 text-white font-mono text-xs tracking-widest uppercase transition-all flex items-center gap-2 group"
            >
                Proceed to Target Selection <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </button>
        )}
      </div>
    </div>
  );
};

export default AuditView;