import React, { useState } from 'react';
import { ArrowLeft, ScanLine } from 'lucide-react';
import { ViewState, NavProps } from '../types';

interface IngestionProps extends NavProps {
  setUsername: (username: string) => void;
}

const IngestionView: React.FC<IngestionProps> = ({ onNavigate, setUsername }) => {
  const [inputVal, setInputVal] = useState('');

  const handleNext = () => {
    if (inputVal.trim()) {
      setUsername(inputVal.trim());
      onNavigate(ViewState.AUDIT);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleNext();
    }
  };

  return (
    <div id="ingestion-view" className="fixed inset-0 z-[70] bg-[#050505] overflow-y-auto animate-in fade-in duration-300">
      <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
        
        {/* Top Nav */}
        <div className="absolute top-12 left-0 right-0 flex flex-col items-center gap-6">
          <div className="px-4 py-1.5 rounded-full border border-white/10 bg-white/5 text-[10px] font-mono text-white/40 tracking-widest">
            STEP 02 / 05
          </div>
          
          <button 
            onClick={() => onNavigate(ViewState.LOGIN)} 
            className="group flex items-center gap-2 text-[10px] font-bold tracking-widest text-white/40 hover:text-white transition-colors uppercase"
          >
            <ArrowLeft className="w-3 h-3 transition-transform group-hover:-translate-x-1" /> Return
          </button>
        </div>

        {/* Content Center */}
        <div className="w-full max-w-2xl flex flex-col items-center mt-12">
            
            {/* Headers */}
            <h1 className="text-5xl md:text-7xl font-sans font-black tracking-tighter text-white mb-2 text-center uppercase">
                Digital Footprint
            </h1>
            <h2 className="text-5xl md:text-7xl font-mono font-bold tracking-tight text-outline mb-10 text-center uppercase">
                Ingestion
            </h2>

            {/* Description */}
            <p className="font-mono text-xs md:text-sm text-[#666] text-center max-w-lg leading-relaxed mb-16">
                Enter primary domain or handle. Our Agentic System will sweep 10 years of public data to reconstruct your brand DNA.
            </p>

            {/* Input Group */}
            <div className="w-full max-w-lg space-y-8">
                <div className="relative group">
                    {/* Purple Glow/Border Effect */}
                    <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-900/50 to-fuchsia-900/50 rounded-lg opacity-50 blur group-hover:opacity-75 transition duration-500"></div>
                    
                    <div className="relative bg-black rounded-lg border border-fuchsia-900/50 flex items-center h-20 px-4 transition-colors focus-within:border-fuchsia-500/60">
                         <input 
                            type="text" 
                            placeholder="@USERNAME" 
                            className="w-full bg-transparent text-center font-mono text-2xl text-white placeholder:text-white/10 focus:outline-none uppercase tracking-widest caret-fuchsia-500 z-10"
                            value={inputVal}
                            onChange={(e) => setInputVal(e.target.value)}
                            onKeyDown={handleKeyDown}
                         />
                         
                         {/* Enter Badge */}
                         <div className="absolute right-4 top-1/2 -translate-y-1/2 z-20">
                            <span className="text-[10px] font-bold text-white/20 bg-white/5 border border-white/5 px-2 py-1 rounded pointer-events-none">ENTER</span>
                         </div>
                    </div>
                </div>

                {/* Action Button */}
                <button 
                  onClick={handleNext} 
                  className="w-full h-14 bg-[#555] hover:bg-[#666] text-black font-bold tracking-[0.2em] text-xs uppercase rounded flex items-center justify-center gap-3 transition-all hover:scale-[1.01] active:scale-[0.99]"
                >
                    Deploy Scraper Agents <ScanLine className="w-4 h-4" />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default IngestionView;