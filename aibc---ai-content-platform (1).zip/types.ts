
export enum ViewState {
  LANDING = 'LANDING',
  LOGIN = 'LOGIN',
  INGESTION = 'INGESTION',
  AUDIT = 'AUDIT',
  VECTORS = 'VECTORS',
  DASHBOARD = 'DASHBOARD'
}

export interface NavProps {
  onNavigate: (view: ViewState) => void;
}

export interface TerminalLog {
  id: string;
  timestamp: string;
  type: 'SYSTEM' | 'AGENT' | 'METRICS' | 'INSIGHT' | 'INFO';
  message: string;
  subType?: string;
}
