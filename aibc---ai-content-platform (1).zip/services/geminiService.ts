import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || ''; // Fallback for dev if env missing, though required by spec

export const generateAuditLogs = async (username: string): Promise<string[]> => {
  if (!apiKey) {
    // Return mock data if no key available to prevent crash in preview without keys
    return [
      "[ANALYSIS] Pattern recognition engaged on target historical data.",
      "[CROSS-REF] 42 data points correlated with known growth vectors.",
      "[SENTIMENT] Audience reception trending positive (0.84 confidence).",
      "[OPTIMIZATION] Identified 3 high-impact content gaps."
    ];
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate 4 futuristic, technical sounding forensic digital audit log lines for a user named "${username}". 
      They should sound like a high-tech AI agent analyzing social media footprint. 
      Format: Just the log message text, one per line. Do not include timestamps or brackets at the start.`,
    });
    
    const text = response.text || '';
    return text.split('\n').filter(line => line.trim().length > 0).slice(0, 4);
  } catch (error) {
    console.error("Gemini API Error:", error);
    return [
       "Connection to Neural Net unstable. Using cached heuristics...",
       "Resuming local analysis of digital footprint.",
       "Scraping public repositories for sentiment analysis.",
       "Compiling user interaction graph."
    ];
  }
};