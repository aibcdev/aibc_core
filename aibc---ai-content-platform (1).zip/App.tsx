
import React, { useState } from 'react';
import LandingView from './components/LandingView';
import LoginView from './components/LoginView';
import IngestionView from './components/IngestionView';
import AuditView from './components/AuditView';
import VectorsView from './components/VectorsView';
import DashboardView from './components/DashboardView';
import { ViewState } from './types';

export default function App() {
  const [view, setView] = useState<ViewState>(ViewState.LANDING);
  const [username, setUsername] = useState<string>('');

  const navigate = (newView: ViewState) => {
    setView(newView);
  };

  return (
    <>
      {view === ViewState.LANDING && <LandingView onNavigate={navigate} />}
      {view === ViewState.LOGIN && <LoginView onNavigate={navigate} />}
      {view === ViewState.INGESTION && <IngestionView onNavigate={navigate} setUsername={setUsername} />}
      {view === ViewState.AUDIT && <AuditView onNavigate={navigate} username={username} />}
      {view === ViewState.VECTORS && <VectorsView onNavigate={navigate} />}
      {view === ViewState.DASHBOARD && <DashboardView onNavigate={navigate} />}
    </>
  );
}
